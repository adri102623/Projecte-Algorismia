import numpy as np
import csv
import time
import sklearn.metrics



k = 8
max_iters = 100

def manhattan_distance(x1, x2):
    return np.sum(np.abs(x1 - x2))

def initialize_centroids_med(X):
    indices = np.random.choice(len(X), k, replace=False)
    return X[indices]

def assign_clusters_med(X, centroids):
    clusters = [[] for _ in range(k)]
    for point in X:
        distances = [manhattan_distance(point, centroid) for centroid in centroids]
        cluster_index = np.argmin(distances)
        clusters[cluster_index].append(point)
    return clusters

def update_centroids_med(clusters):
    centroids = np.zeros((k, len(clusters[0][0])))
    for i, cluster in enumerate(clusters):
        cluster = np.array(cluster)
        centroids[i] = np.median(cluster, axis=0)
    return centroids

def clustering_med(X):
    centroids = initialize_centroids_med(X)
    prev_centroids = None
    iteration = 0

    while iteration < max_iters and not np.array_equal(prev_centroids, centroids):
        clusters = assign_clusters_med(X, centroids)
        prev_centroids = centroids
        centroids = update_centroids_med(clusters)
        iteration += 1

    return centroids, clusters






##LOAD##

def load_dataset(file_path, dimensiones, etiquetado):
    # Definir una función de conversión para reemplazar las comas por puntos
    def comma_to_point(value):
        return float(value.decode('utf-8').replace(',', '.'))

    # Cargar el dataset convirtiendo las comas en puntos
    data = np.genfromtxt(file_path, delimiter=';', skip_header=1, usecols=list(range(dimensiones - etiquetado)),converters={i: comma_to_point for i in range(1, dimensiones)})
    return data[:,:]  # Excluir la primera columna (índices)






##MAIN##
            

# Ruta del archivo del dataset

file_path = "datasets/Dataset5.csv"
dimensiones = 24
etiquetado = 0 #0 no / 1 si

# Cargar el dataset
Y = load_dataset(file_path, dimensiones, etiquetado)




# Aplicamos el algoritmo K-Medians
inicio = time.time()
centroids, clusters = clustering_med(Y[:])
fin = time.time()
tiempo_transcurrido = fin - inicio



S = []
labels = []
for i, cluster in enumerate(clusters):
    for punto in cluster:
        labels.append(i)
        S.append(punto)


print("Davies score: ")
print(sklearn.metrics.davies_bouldin_score(S,labels))

print("Tiempo: ")
print(tiempo_transcurrido)




