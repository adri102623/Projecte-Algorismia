Nombre d'instàncies: n = 3810
Dimensions ("features"): d = 7
Nombre de clústers: k = 2
Etiquetat: Sí


