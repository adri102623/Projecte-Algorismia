Nombre d'instàncies: n = 5456
Dimensions ("features"): d = 24
Nombre de clústers: k = ??
Etiquetat: No



