Nombre d'instàncies: n = 299
Dimensions ("features"): d = 12
Nombre de clústers: k = 2
Etiquetat: Sí


