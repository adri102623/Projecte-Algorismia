Nombre d'instàncies: n = 50000
Dimensions ("features"): d = 2
Nombre de clústers: k = 3
Etiquetat: No



