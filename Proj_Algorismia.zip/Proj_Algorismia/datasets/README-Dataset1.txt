Nombre d'instàncies: n = 13611
Dimensions ("features"): d = 16
Nombre de clústers: k = 7
Etiquetat: Sí

