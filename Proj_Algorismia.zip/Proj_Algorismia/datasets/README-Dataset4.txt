Nombre d'instàncies: n = 980
Dimensions ("features"): d = 10
Nombre de clústers: k = ??
Etiquetat: No



