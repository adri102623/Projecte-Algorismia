import numpy as np
import csv

k = 3
max_iters = 100

def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2)**2))

def initialize_centroids(X):
    centroids = X.copy()
    np.random.shuffle(centroids)
    return centroids[:k]

def assign_clusters(X, centroids):
    clusters = [[] for _ in range(k)]
    for point in X:
        distances = [euclidean_distance(point, centroid) for centroid in centroids]
        cluster_index = np.argmin(distances)
        clusters[cluster_index].append(point)
    return clusters

def update_centroids(clusters):
    centroids = np.zeros((k, clusters[0][0].shape[0]))
    for i, cluster in enumerate(clusters):
        cluster_mean = np.mean(cluster, axis=0)
        centroids[i] = cluster_mean
    return centroids

def escribir_datos_a_csv(datos, archivo_csv):
    with open(archivo_csv, 'w', newline='') as archivo:
        escritor_csv = csv.writer(archivo)
        for cluster in datos:
            fila_formateada = "[" + "],[".join([",".join([f'{valor:.1f}' for valor in punto]) for punto in cluster]) + "]"
            escritor_csv.writerow([fila_formateada])

def clustering(X):
    centroids = initialize_centroids(X)

    for _ in range(max_iters):
        clusters = assign_clusters(X, centroids)
        prev_centroids = centroids
        centroids = update_centroids(clusters)

        if np.array_equal(prev_centroids, centroids):
            break

    return centroids, clusters

def load_dataset(file_path, dimensiones, etiquetado):
    # Definir una función de conversión para reemplazar las comas por puntos
    def comma_to_point(value):
        return float(value.decode('utf-8').replace(',', '.'))

    # Cargar el dataset convirtiendo las comas en puntos
    data = np.genfromtxt(file_path, delimiter=';', skip_header=1, usecols=list(range(dimensiones - etiquetado)),converters={i: comma_to_point for i in range(1, dimensiones)})
    return data[:,:]  # Excluir la primera columna (índices)

# Ruta del archivo del dataset

file_path = "datasets/Dataset1.csv"
dimensiones = 16
etiquetado = 1 #0 no / 1 si

# Cargar el dataset
X = load_dataset(file_path, dimensiones, etiquetado)




# Aplicar el algoritmo K-Means
centroids, clusters = clustering(X)

# Imprimir los resultados
print("Centroides finales:")
print(centroids)
print("Clústers finales:")
for i, cluster in enumerate(clusters):
    print(f"Cluster {i+1}:")
    print(cluster)







# # Guardar los clusters en un archivo CSV
# clusters_kmeans = 'clusters_kmeans.csv'
# escribir_datos_a_csv(clusters, clusters_kmeans)
