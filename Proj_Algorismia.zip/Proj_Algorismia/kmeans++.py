import numpy as np
import matplotlib.pyplot as plt

k = 3
max_iters = 100

def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2)**2))

def initialize_centroids(X):
    n_samples, n_features = X.shape
    centroids = np.zeros((k, n_features))
    
    # Step 1: Select the first centroid randomly
    centroids[0] = X[np.random.choice(n_samples)]
    
    # Step 2 and 3: Select the next centroids with probability proportional to squared distance
    for i in range(1, k):
        distances = np.array([min([euclidean_distance(c, x) for c in centroids[:i]]) for x in X])
        probs = distances / distances.sum()
        centroids[i] = X[np.random.choice(n_samples, p=probs)]
    
    return centroids

def assign_clusters(X, centroids):
    clusters = [[] for _ in range(k)]
    for point in X:
        distances = [euclidean_distance(point, centroid) for centroid in centroids]
        cluster_index = np.argmin(distances)
        clusters[cluster_index].append(point)
    return clusters

def update_centroids(clusters):
    centroids = np.zeros((len(clusters), len(clusters[0][0])))  # Inicializar con la forma correcta
    for i in range(len(clusters)):
        cluster = np.array(clusters[i])
        centroids[i] = np.mean(cluster, axis=0)
    return centroids


def clustering(X):
    centroids = initialize_centroids(X)
    iteration = 0

    while iteration < max_iters:
        clusters = assign_clusters(X, centroids)
        new_centroids = update_centroids(clusters)

        if np.array_equal(centroids, new_centroids):
            break

        centroids = new_centroids
        iteration += 1

    return centroids, clusters

def plot_clusters(X, clusters, centroids):
    colors = ['r', 'g', 'b', 'y', 'c', 'm']
    plt.figure(figsize=(8, 6))

    for i in range(len(clusters)):
        for point in clusters[i]:
            plt.scatter(point[0], point[1], color=colors[i], s=30)

    for centroid in centroids:
        plt.scatter(centroid[0], centroid[1], marker='x', color='k', s=100)

    plt.title('K-Means++ Clustering')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.grid(True)
    plt.show()

# Ejemplo de uso:
if __name__ == "__main__":
    # Supongamos que tienes un conjunto de datos X
    X = np.array([[1, 2], [1.5, 1.8], [5, 8], [8, 8], [1, 0.6], [9, 11]])

    # Aplicamos el algoritmo K-Means++
    centroids, clusters = clustering(X)

    print("Centroides finales:")
    print(centroids)
    print("Clústers finales:")
    for i in range(len(clusters)):
        print(f"Cluster {i+1}:")
        print(clusters[i])

    # Visualizamos los clústers
    plot_clusters(X, clusters, centroids)
