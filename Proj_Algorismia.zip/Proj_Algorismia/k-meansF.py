import numpy as np
import csv
import time
import sklearn.metrics

##K-MEANS##

k = 8
max_iters = 100

def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2)**2))

def initialize_centroids(X):
    centroids = X.copy()
    np.random.shuffle(centroids)
    return centroids[:k]

def assign_clusters(X, centroids):
    clusters = [[] for _ in range(k)]
    for point in X:
        distances = [euclidean_distance(point, centroid) for centroid in centroids]
        cluster_index = np.argmin(distances)
        clusters[cluster_index].append(point)
    return clusters

def update_centroids(clusters):
    centroids = np.zeros((k, clusters[0][0].shape[0]))
    for i, cluster in enumerate(clusters):
        cluster_mean = np.mean(cluster, axis=0)
        centroids[i] = cluster_mean
    return centroids


def clustering(X):
    centroids = initialize_centroids(X)

    for _ in range(max_iters):
        clusters = assign_clusters(X, centroids)
        prev_centroids = centroids
        centroids = update_centroids(clusters)

        if np.array_equal(prev_centroids, centroids):
            break

    return centroids, clusters






##LOAD##

def load_dataset(file_path, dimensiones, etiquetado):
    # Definir una función de conversión para reemplazar las comas por puntos
    def comma_to_point(value):
        return float(value.decode('utf-8').replace(',', '.'))

    # Cargar el dataset convirtiendo las comas en puntos
    data = np.genfromtxt(file_path, delimiter=';', skip_header=1, usecols=list(range(dimensiones - etiquetado)),converters={i: comma_to_point for i in range(1, dimensiones)})
    return data[:,:]  # Excluir la primera columna (índices)






##MAIN##
            

# Ruta del archivo del dataset

file_path = "datasets/Dataset5.csv"
dimensiones = 24
etiquetado = 0 #0 no / 1 si

# Cargar el dataset
Y = load_dataset(file_path, dimensiones, etiquetado)


# Aplicar el algoritmo K-Means
inicio = time.time()
centroids, clusters = clustering(Y)
fin = time.time()
tiempo_transcurrido = fin - inicio


S = []
labels = []
for i, cluster in enumerate(clusters):
    for punto in cluster:
        labels.append(i)
        S.append(punto)


print("Davies score: ")
print(sklearn.metrics.davies_bouldin_score(S,labels))

print("Tiempo Lloyd: ")
print(tiempo_transcurrido)
